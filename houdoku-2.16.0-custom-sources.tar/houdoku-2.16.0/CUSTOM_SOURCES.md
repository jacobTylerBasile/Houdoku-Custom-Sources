# Custom sources

Houdoku can read from any website you describe, without writing code. Create a file named
`custom-sources.json` in Houdoku's user data folder:

- macOS:   `~/Library/Application Support/Houdoku/`
- Windows: `%APPDATA%\Houdoku\`
- Linux:   `~/.config/Houdoku/`

then restart Houdoku, or use the Plugins tab's reload. Each entry appears as a source in Search.

The file is an array of source definitions. This example uses a made-up site; replace every
URL and selector with the ones that match the site you want to read (use your browser's
"Inspect element" to find them).

```json
[
  {
    "id": "my-example-source",
    "name": "Example Site",
    "baseUrl": "https://example.org",
    "language": "ENGLISH",
    "headers": { "Referer": "https://example.org/" },

    "search": {
      "url": "{base}/search?q={query}&page={page}",
      "itemSelector": ".result-card",
      "linkSelector": "a.title",
      "titleSelector": "a.title",
      "coverSelector": "img",
      "coverAttrs": ["data-src", "src"],
      "nextPageSelector": "a.next"
    },
    "directory": {
      "url": "{base}/browse?page={page}",
      "itemSelector": ".result-card",
      "linkSelector": "a.title",
      "coverSelector": "img",
      "nextPageSelector": "a.next"
    },
    "series": {
      "titleSelector": "h1.series-title",
      "descriptionSelector": ".summary",
      "coverSelector": ".cover img",
      "authorSelector": ".author a",
      "tagSelector": ".genres a",
      "statusSelector": ".status"
    },
    "chapters": {
      "itemSelector": "ul.chapters li a",
      "numberRegex": "Chapter\\s+(\\d+(?:\\.\\d+)?)"
    },
    "pages": {
      "imageSelector": ".reader img",
      "imageAttrs": ["data-src", "src"]
    }
  }
]
```

Notes:
- URL templates accept `{base}`, `{query}` (URL-encoded) and `{page}` (starts at 1).
- Only static HTML is parsed. Sites that build their page lists with JavaScript or sit behind a
  login/Cloudflare challenge won't work with this method.
- Invalid entries are skipped and logged to Houdoku's log; the rest still load.
- You are responsible for making sure you have the right to read and copy content from any
  site you add.
