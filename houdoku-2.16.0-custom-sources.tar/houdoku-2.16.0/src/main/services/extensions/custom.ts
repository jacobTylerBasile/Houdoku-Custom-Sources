import fs from 'fs';
import path from 'path';
import fetch from 'node-fetch';
import { JSDOM } from 'jsdom';
import {
  Chapter,
  ExtensionClientAbstract,
  ExtensionMetadata,
  FilterOption,
  GetChaptersFunc,
  GetDirectoryFunc,
  GetFilterOptionsFunc,
  GetImageFunc,
  GetPageRequesterDataFunc,
  GetPageUrlsFunc,
  GetSearchFunc,
  GetSeriesFunc,
  GetSettingsFunc,
  GetSettingTypesFunc,
  LanguageKey,
  PageRequesterData,
  Series,
  SeriesListResponse,
  SeriesStatus,
  SetSettingsFunc,
} from '@tiyo/common';

/**
 * A user-defined content source, described entirely by CSS selectors.
 *
 * Definitions live in `custom-sources.json` in Houdoku's user data folder (an array of these).
 * Nothing here is specific to any website; the user supplies the URLs and selectors.
 */
export type CustomSourceDefinition = {
  /** Unique id for the source. Any stable string, e.g. a UUID. */
  id: string;
  name: string;
  /** Site root, e.g. "https://example.org". Relative links are resolved against it. */
  baseUrl: string;
  /** One of the LanguageKey values (e.g. "ENGLISH"). Defaults to ENGLISH. */
  language?: string;
  /** Extra HTTP headers sent with every request (e.g. Referer, User-Agent). */
  headers?: Record<string, string>;

  /** URL templates support {base}, {query} (url-encoded) and {page} (starting at 1). */
  search: ListConfig;
  /** Optional separate "browse" page. If omitted, search with an empty query is used. */
  directory?: ListConfig;
  series: SeriesConfig;
  chapters: ChaptersConfig;
  pages: PagesConfig;
};

type ListConfig = {
  url: string;
  /** Selector for each result card. */
  itemSelector: string;
  /** Selector (within a card) for the <a> to the series. Defaults to the card itself. */
  linkSelector?: string;
  /** Selector (within a card) for the title text. Defaults to the link's text. */
  titleSelector?: string;
  /** Selector (within a card) for the cover <img>. */
  coverSelector?: string;
  /** Attribute(s) to read the cover URL from, in order. Defaults to ["src"]. */
  coverAttrs?: string[];
  /** If this selector matches anything on the page, there is a next page. */
  nextPageSelector?: string;
};

type SeriesConfig = {
  titleSelector: string;
  descriptionSelector?: string;
  coverSelector?: string;
  coverAttrs?: string[];
  authorSelector?: string;
  tagSelector?: string;
  /** Selector whose text contains a status word (ongoing / completed / ...). */
  statusSelector?: string;
};

type ChaptersConfig = {
  /** Where to find the chapter list. Defaults to the series page URL. */
  url?: string;
  itemSelector: string;
  /** Selector (within an item) for the <a>. Defaults to the item itself. */
  linkSelector?: string;
  /** Selector (within an item) for the title text. Defaults to the link's text. */
  titleSelector?: string;
  /** Regex whose first capture group is the chapter number, applied to the title. */
  numberRegex?: string;
  /** Set true if the site lists newest chapters first (informational; ordering is by number). */
  newestFirst?: boolean;
};

type PagesConfig = {
  /** Selector for the page images in a chapter. */
  imageSelector: string;
  /** Attribute(s) to read the image URL from, in order. Defaults to ["src"]. */
  imageAttrs?: string[];
};

const DEFAULT_HEADERS = {
  'User-Agent':
    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0 Safari/537.36',
};

export const CUSTOM_SOURCES_FILENAME = 'custom-sources.json';

const absolute = (href: string, base: string): string => {
  try {
    return new URL(href.trim(), base).toString();
  } catch {
    return '';
  }
};

const firstAttr = (el: Element | null, attrs: string[]): string => {
  if (!el) return '';
  for (const attr of attrs) {
    const value = el.getAttribute(attr);
    if (value && value.trim()) return value.trim();
  }
  return '';
};

const text = (root: ParentNode, selector?: string): string => {
  if (!selector) return '';
  return (root.querySelector(selector)?.textContent ?? '').replace(/\s+/g, ' ').trim();
};

const parseStatus = (raw: string): SeriesStatus => {
  const lower = raw.toLowerCase();
  if (lower.includes('complete') || lower.includes('finished')) return SeriesStatus.COMPLETED;
  if (lower.includes('cancel') || lower.includes('drop')) return SeriesStatus.CANCELLED;
  if (lower.includes('ongoing') || lower.includes('publishing')) return SeriesStatus.ONGOING;
  return SeriesStatus.ONGOING;
};

export class CustomExtensionClient extends ExtensionClientAbstract {
  readonly definition: CustomSourceDefinition;
  readonly metadata: ExtensionMetadata;

  constructor(definition: CustomSourceDefinition) {
    super(() => Promise.reject(new Error('webFetch is not used by custom sources')));
    this.definition = definition;
    this.metadata = {
      id: definition.id,
      name: definition.name,
      url: definition.baseUrl,
      translatedLanguage: (definition.language as LanguageKey | undefined) ?? LanguageKey.ENGLISH,
    };
  }

  private headers(): Record<string, string> {
    return {
      ...DEFAULT_HEADERS,
      Referer: this.definition.baseUrl,
      ...(this.definition.headers ?? {}),
    };
  }

  private async fetchDocument(url: string): Promise<Document> {
    const res = await fetch(url, { headers: this.headers() });
    if (!res.ok) throw new Error(`Request to ${url} failed with status ${res.status}`);
    return new JSDOM(await res.text()).window.document;
  }

  private expand(template: string, query: string, page: number): string {
    return template
      .replace(/\{base\}/g, this.definition.baseUrl.replace(/\/$/, ''))
      .replace(/\{query\}/g, encodeURIComponent(query))
      .replace(/\{page\}/g, String(page));
  }

  private async fetchList(
    config: ListConfig,
    query: string,
    page: number,
  ): Promise<SeriesListResponse> {
    const url = this.expand(config.url, query, page);
    const doc = await this.fetchDocument(url);
    const coverAttrs = config.coverAttrs ?? ['src'];

    const seriesList: Series[] = [];
    doc.querySelectorAll(config.itemSelector).forEach((item) => {
      const link = config.linkSelector ? item.querySelector(config.linkSelector) : item;
      const href = link?.getAttribute('href');
      if (!href) return;
      const sourceId = absolute(href, url);
      if (!sourceId) return;

      const title =
        text(item, config.titleSelector) || (link?.textContent ?? '').replace(/\s+/g, ' ').trim();
      const cover = config.coverSelector ? item.querySelector(config.coverSelector) : null;
      const coverUrl = absolute(firstAttr(cover, coverAttrs), url);

      seriesList.push({
        id: undefined,
        extensionId: this.definition.id,
        sourceId,
        title,
        altTitles: [],
        description: '',
        authors: [],
        artists: [],
        tags: [],
        status: SeriesStatus.ONGOING,
        originalLanguageKey: LanguageKey.JAPANESE,
        numberUnread: 0,
        remoteCoverUrl: coverUrl,
        trackerKeys: {},
      });
    });

    const hasMore = config.nextPageSelector ? doc.querySelector(config.nextPageSelector) !== null : false;
    return { seriesList, hasMore };
  }

  override getSeries: GetSeriesFunc = async (id: string) => {
    const cfg = this.definition.series;
    const doc = await this.fetchDocument(id);
    const cover = cfg.coverSelector ? doc.querySelector(cfg.coverSelector) : null;

    const listText = (selector?: string): string[] => {
      if (!selector) return [];
      return Array.from(doc.querySelectorAll(selector))
        .map((el) => (el.textContent ?? '').replace(/\s+/g, ' ').trim())
        .filter((s) => s.length > 0);
    };

    const series: Series = {
      id: undefined,
      extensionId: this.definition.id,
      sourceId: id,
      title: text(doc, cfg.titleSelector) || id,
      altTitles: [],
      description: text(doc, cfg.descriptionSelector),
      authors: listText(cfg.authorSelector),
      artists: [],
      tags: listText(cfg.tagSelector),
      status: parseStatus(text(doc, cfg.statusSelector)),
      originalLanguageKey: LanguageKey.JAPANESE,
      numberUnread: 0,
      remoteCoverUrl: absolute(firstAttr(cover, cfg.coverAttrs ?? ['src']), id),
      trackerKeys: {},
    };
    return series;
  };

  override getChapters: GetChaptersFunc = async (id: string) => {
    const cfg = this.definition.chapters;
    const url = cfg.url ? absolute(this.expand(cfg.url, '', 1), id) : id;
    const doc = await this.fetchDocument(url);
    const numberRegex = cfg.numberRegex ? new RegExp(cfg.numberRegex) : null;

    const chapters: Chapter[] = [];
    doc.querySelectorAll(cfg.itemSelector).forEach((item, index) => {
      const link = cfg.linkSelector ? item.querySelector(cfg.linkSelector) : item;
      const href = link?.getAttribute('href');
      if (!href) return;
      const sourceId = absolute(href, url);
      if (!sourceId) return;

      const title =
        text(item, cfg.titleSelector) || (link?.textContent ?? '').replace(/\s+/g, ' ').trim();
      const match = numberRegex ? title.match(numberRegex) : title.match(/(\d+(?:\.\d+)?)/);
      const chapterNumber = match && match[1] ? String(parseFloat(match[1])) : String(index + 1);

      chapters.push({
        sourceId,
        title,
        chapterNumber,
        volumeNumber: '',
        languageKey: (this.definition.language as LanguageKey | undefined) ?? LanguageKey.ENGLISH,
        groupName: '',
        time: new Date().getTime(),
        read: false,
      });
    });
    return chapters;
  };

  override getPageRequesterData: GetPageRequesterDataFunc = async (
    _seriesSourceId: string,
    chapterSourceId: string,
  ) => {
    const cfg = this.definition.pages;
    const doc = await this.fetchDocument(chapterSourceId);
    const attrs = cfg.imageAttrs ?? ['src'];

    const pageUrls: string[] = [];
    doc.querySelectorAll(cfg.imageSelector).forEach((img) => {
      const src = absolute(firstAttr(img, attrs), chapterSourceId);
      if (src) pageUrls.push(src);
    });

    const data: PageRequesterData = {
      server: '',
      hash: '',
      numPages: pageUrls.length,
      pageFilenames: pageUrls,
    };
    return data;
  };

  override getPageUrls: GetPageUrlsFunc = (pageRequesterData: PageRequesterData) => {
    return pageRequesterData.pageFilenames;
  };

  /**
   * Images are fetched here, in the main process, so the configured Referer/User-Agent headers
   * are sent (many hosts reject requests without them).
   */
  override getImage: GetImageFunc = async (_series: Series, url: string) => {
    if (!url) return '';
    const res = await fetch(url, { headers: this.headers() });
    if (!res.ok) throw new Error(`Image request to ${url} failed with status ${res.status}`);
    const buffer = await res.arrayBuffer();
    return buffer as ArrayBuffer;
  };

  override getSearch: GetSearchFunc = (query: string, page: number) => {
    return this.fetchList(this.definition.search, query, page);
  };

  override getDirectory: GetDirectoryFunc = (page: number) => {
    return this.fetchList(this.definition.directory ?? this.definition.search, '', page);
  };

  override getSettingTypes: GetSettingTypesFunc = () => ({});
  override getSettings: GetSettingsFunc = () => ({});
  override setSettings: SetSettingsFunc = () => {};
  override getFilterOptions: GetFilterOptionsFunc = (): FilterOption[] => [];
}

const REQUIRED_STRINGS: (keyof CustomSourceDefinition)[] = ['id', 'name', 'baseUrl'];

const isValidDefinition = (def: unknown): def is CustomSourceDefinition => {
  if (typeof def !== 'object' || def === null) return false;
  const d = def as Record<string, unknown>;
  if (!REQUIRED_STRINGS.every((key) => typeof d[key] === 'string' && (d[key] as string).length > 0))
    return false;
  const obj = (key: string) => typeof d[key] === 'object' && d[key] !== null;
  return obj('search') && obj('series') && obj('chapters') && obj('pages');
};

/**
 * Load custom source definitions from `<userData>/custom-sources.json`.
 * Invalid entries are skipped with a warning rather than failing the whole file.
 */
export const loadCustomSources = (userDataDir: string): CustomExtensionClient[] => {
  const file = path.join(userDataDir, CUSTOM_SOURCES_FILENAME);
  if (!fs.existsSync(file)) return [];

  let parsed: unknown;
  try {
    parsed = JSON.parse(fs.readFileSync(file, 'utf-8'));
  } catch (err) {
    console.error(`Could not parse ${file}:`, err);
    return [];
  }
  if (!Array.isArray(parsed)) {
    console.error(`${file} must contain a JSON array of source definitions`);
    return [];
  }

  const clients: CustomExtensionClient[] = [];
  const seen = new Set<string>();
  parsed.forEach((def, i) => {
    if (!isValidDefinition(def)) {
      console.warn(`Skipping invalid custom source at index ${i} in ${file}`);
      return;
    }
    if (seen.has(def.id)) {
      console.warn(`Skipping custom source "${def.name}": duplicate id ${def.id}`);
      return;
    }
    seen.add(def.id);
    clients.push(new CustomExtensionClient(def));
  });
  console.info(`Loaded ${clients.length} custom source(s) from ${file}`);
  return clients;
};
